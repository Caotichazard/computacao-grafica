#ifndef WHEREISMYMOUSE_H_INCLUDED
#define WHEREISMYMOUSE_H_INCLUDED

#include "linklist.h"

int captureMouse(void);


#endif